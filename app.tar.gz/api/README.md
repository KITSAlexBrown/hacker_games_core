#KF Mood tracker API

## Installation

```bash
npm install
npm start
```

## Install docker and mongo

```bash
 docker run --name api-mongo -v /data/db -p 27017:27017 -d mongo 
```

Data will get backed up to the data dir when we do an export

http://10.51.9.65:4000/api/users


## Natrual language lib

```sh
https://github.com/nhunzaker/speakeasy
```